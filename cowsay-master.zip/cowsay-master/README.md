# intro-a-node
Estos son algunos ejercicios para aprender a usar nodejs y git

Es necesario usar node_modules. -> npm install
Para correr el Cowsay.
